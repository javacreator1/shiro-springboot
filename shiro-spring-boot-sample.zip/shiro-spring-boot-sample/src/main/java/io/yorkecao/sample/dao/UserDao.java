package io.yorkecao.sample.dao;

import io.yorkecao.sample.entity.RolePermission;
import io.yorkecao.sample.entity.User;
import io.yorkecao.sample.entity.UserRole;

import java.util.List;

public interface UserDao {
    public User getUserByUserName(String userName);

    public List<UserRole> getUserRolesByUserName(String userName);

    public List<RolePermission> getRolePermissionsByRoleName(String roleName);

}
