package io.yorkecao.sample;

import io.yorkecao.sample.dao.UserDao;
import io.yorkecao.sample.entity.RolePermission;
import io.yorkecao.sample.entity.User;
import io.yorkecao.sample.entity.UserRole;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;

@SpringBootApplication
public class ShiroSpringBootSampleApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext = SpringApplication.run(ShiroSpringBootSampleApplication.class, args);

		/*UserDao userDao = (UserDao) applicationContext.getBean("userDaoImpl");
		List<RolePermission> list = userDao.getRolePermissionsByRoleName("admin");
		System.out.println(list);*/

		/*List<UserRole> list = userDao.getUserRolesByUserName("mark");
		System.out.println(list);*/

		/*User user = userDao.getUserByUserName("jerry");
		System.out.println(user);*/
	}
}
