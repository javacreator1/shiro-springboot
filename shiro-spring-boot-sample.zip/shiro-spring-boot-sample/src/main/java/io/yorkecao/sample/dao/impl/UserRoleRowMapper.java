package io.yorkecao.sample.dao.impl;

import io.yorkecao.sample.entity.UserRole;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRoleRowMapper implements RowMapper<UserRole> {
    @Override
    public UserRole mapRow(ResultSet resultSet, int i) throws SQLException {
        UserRole userRole=new UserRole();
        userRole.setId(resultSet.getInt("id"));
        userRole.setUserName(resultSet.getString("username"));
        userRole.setRoleName(resultSet.getString("role_name"));
        return userRole;
    }
}
