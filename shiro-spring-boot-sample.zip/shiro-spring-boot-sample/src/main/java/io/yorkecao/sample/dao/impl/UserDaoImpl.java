package io.yorkecao.sample.dao.impl;

import io.yorkecao.sample.dao.UserDao;
import io.yorkecao.sample.entity.RolePermission;
import io.yorkecao.sample.entity.User;
import io.yorkecao.sample.entity.UserRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class UserDaoImpl implements UserDao {
    @Autowired
    public JdbcTemplate jdbcTemplate;
    @Override
    public User getUserByUserName(String userName) {
        String sql="select * from users where username=?";
        User user = jdbcTemplate.queryForObject(sql, new String[]{userName}, new UserRowMapper());
        return user;
    }

    @Override
    public List<UserRole> getUserRolesByUserName(String userName) {
        String sql="select * from user_roles where username=?";
        List<UserRole> list = jdbcTemplate.query(sql, new UserRoleRowMapper(),userName);
        return list;
    }

    @Override
    public List<RolePermission> getRolePermissionsByRoleName(String roleName) {
        String sql = "select * from role_permissions where role_name=?";
        List<RolePermission> list = jdbcTemplate.query(sql, new RolePermissionRowMapper(), roleName);
        return list;
    }
}
