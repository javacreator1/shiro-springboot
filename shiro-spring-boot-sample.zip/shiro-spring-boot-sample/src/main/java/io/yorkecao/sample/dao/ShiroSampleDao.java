package io.yorkecao.sample.dao;

import io.yorkecao.sample.entity.RolePermission;
import io.yorkecao.sample.entity.User;
import io.yorkecao.sample.entity.UserRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * @author Yorke
 */
@Repository
public class ShiroSampleDao {

    @Autowired
    public UserDao userDao;

    public Set<String> getRolesByUsername(String username) {
        Set<String> roles = new HashSet<>();
        List<UserRole> list = userDao.getUserRolesByUserName(username);
        for (UserRole userRole : list) {
            roles.add(userRole.getRoleName());
        }
        /*switch (username) {
            case "zhangsan":
                roles.add("admin");
                break;
            case "lisi":
                roles.add("guest");
                break;
        }*/
        return roles;
    }

    public Set<String> getPermissionsByRole(String role) {
        Set<String> permissions = new HashSet<>();
        List<RolePermission> list = userDao.getRolePermissionsByRoleName(role);
        for (RolePermission rolePermission : list) {
            permissions.add(rolePermission.getPermission());
        }
        /*switch (role) {
            case "admin":
                permissions.add("read");
                permissions.add("write");
                break;
            case "guest":
                permissions.add("read");
                break;
        }*/
        return permissions;
    }

    public String getPasswordByUsername(String username) {
        User user = userDao.getUserByUserName(username);
        return user.getPassword();
    }
}
