package io.yorkecao.sample.dao.impl;

import io.yorkecao.sample.entity.RolePermission;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RolePermissionRowMapper implements RowMapper {
    @Override
    public Object mapRow(ResultSet resultSet, int i) throws SQLException {
        RolePermission rolePermission=new RolePermission();
        rolePermission.setId(resultSet.getInt("id"));
        rolePermission.setPermission(resultSet.getString("permission"));
        rolePermission.setRoleName(resultSet.getString("role_name"));
        return rolePermission;
    }
}
